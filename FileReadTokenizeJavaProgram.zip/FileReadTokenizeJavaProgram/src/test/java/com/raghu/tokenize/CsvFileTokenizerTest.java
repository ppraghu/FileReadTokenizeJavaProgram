package com.raghu.tokenize;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import java.io.IOException;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

public class CsvFileTokenizerTest {
    private static final String TEST_CSV_FILE = "src/test/resources/test_data.csv";
    private CsvFileTokenizer csvFileTokenizer;

    @Before
    public void setUp() {
        csvFileTokenizer = new CsvFileTokenizer();
    }
    @Test
    public void testReadFile() throws IOException {
        List<CsvFileTokenizer.Trend> trends = csvFileTokenizer.readFile(TEST_CSV_FILE, "|");
        assertNotNull(trends);
        assertEquals(trends.size(), 4);
        assertEquals(trends.get(0).toString(), "Trend{id=1, index=20.29, desc='python'}");
        assertEquals(trends.get(1).toString(), "Trend{id=2, index=4.345, desc='java'}");
        assertEquals(trends.get(2).toString(), "Trend{id=3, index=9.99, desc='nodejs'}");
        assertEquals(trends.get(3).toString(), "Trend{id=4, index=10.7, desc='react'}");
    }
    @Test(expected = IOException.class)
    public void testReadFileWithIOException() throws IOException {
        csvFileTokenizer.readFile(TEST_CSV_FILE + "x", "|");
    }
}